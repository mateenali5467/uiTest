
import Home from "./Cmp/Home";


function App() {
  return (
   <>
     <Home />
   </>
  );
}

export default App;

import "./signup.css";


const signUp = ()=>{
    const design = (
        <>
         <div className="container mt-custom">
               <div className="row">
               <div className="col-md-1"></div>
                 <div className="col-md-5  mt-sm-2 mt-md-5 mb-5">
                    <img className="p-0 m-0" width="330"  src="https://static.xx.fbcdn.net/rsrc.php/y8/r/dF5SId3UHWd.svg"  />
                    <p className="p-0 m-0 " style={{fontSize:"26px",position:"relative",left:"30px",top:0}}>Facebook helps you connect and share with the people in your life</p>
                 </div>
                 <div className="col-md-1"></div>
                 <div className="col-md-5">
                    <div className="p-3" id="bg-white">
                    <div >
                       <input id="input-field" className="form-control mb-3" placeholder="Email Address or phone number" />
                       <input id="input-field"  className="form-control" placeholder="Password"/> 
                       <button id="fb-btn"  className=" text-white mt-3">Log in</button>
                       <center>
                       <p className="mb-3 mt-3"> <a className="mb-3 mt-3" >Forgotten Password</a></p>
                      
                       <hr></hr>
                       <button className="btn  mt-3 p-2" style={{backgroundColor:"#42b72a",color:"white",fontSize:"20px"}}>Create New Account</button>
                       </center>
                    </div>
                    </div>
                    <center><p className="mt-3"><b>Create a Page</b> for a celebrity, brand or business.</p></center>
                 </div>
               </div>
           </div>
        </>
    );
    return design;
}

export default signUp;
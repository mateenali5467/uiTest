

import SignUp from "./Signup/Signup";

const Home = ()=>{
    return (
        <>
        <SignUp />
        </>
    );
}
export default Home;